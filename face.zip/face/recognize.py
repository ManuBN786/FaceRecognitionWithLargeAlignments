'''
Description : Face Recognition with large tilts in faces using Dlib & OpenCV 3.2
Author      : Manu BN
'''


import sys

sys.path.append('/usr/local/lib/python3.5/site-packages')
import cv2
from imutils.face_utils import FaceAligner
from imutils.face_utils import rect_to_bb
import argparse
import imutils
import dlib
import numpy as np
import train
import detect
import config

# initialize dlib's face detector (HOG-based) and then create
# the facial landmark predictor and the face aligner
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")
fa = FaceAligner(predictor)

def RecognizeFace(image,threshold):
#def RecognizeFace(image, faceCascade, eyeCascade, faceSize, threshold):
    found_faces = []

    #gray, faces = detect.detectFaces(image, faceCascade, eyeCascade, returnGray=1)

    # Use dlib's face detector instead

    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    rects = detector(gray, 2)

    converted_rects = []
    for rect in rects:
        (x1,y1,w1,h1) = rect_to_bb(rect)
        faceOrig = imutils.resize(image[y1:y1 + h1, x1:x1 + w1], width=256)
        #new_rect = []
        #new_rect.x = x1
        #new_rect.y = y1
       # new_rect.w = w1
       # new_rect.h = h1
       # converted_rects.append(new_rect)
        faceAligned = fa.align(image, gray, (rect))
        faceAligned_Gray = cv2.cvtColor(faceAligned, cv2.COLOR_BGR2GRAY)
        faceAligned_Gray = cv2.resize(faceAligned_Gray, (200, 200))
        cv2.imshow("Original", faceOrig)
        cv2.imshow("Aligned", faceAligned)
        label, confidence = recognizer.predict(faceAligned_Gray)
        print(label)


        if confidence < threshold:
         found_faces.append((label, confidence, (x1, y1, w1, h1)))

    return found_faces


'''
    # If faces are found, try to recognize them
    #for rect in rects:
    for ((rect),eyedim) in rects:
        (x,y,w,h) = rect_to_bb(rect)
        faceOrig = imutils.resize(image[y:y + h, x:x + w], width=256)
        faceAligned = fa.align(image, gray, (rect))
        #label, confidence = recognizer.predict(faceAligned)
        print(x,y)
        # display the output images
        cv2.imshow("Original", faceOrig)
        cv2.imshow("Aligned", faceAligned)


        faceAligned_Gray = cv2.cvtColor(faceAligned, cv2.COLOR_BGR2GRAY)
        faceAligned_Gray = cv2.resize(faceAligned_Gray, (200,200))
        #label, confidence = recognizer.predict(faceAligned_Gray)
        label, confidence = recognizer.predict(cv2.resize(detect.levelFace(faceAligned_Gray, ((x, y, w, h), eyedim)), faceSize))

       # label, confidence = recognizer.predict(cv2.resize(detect.levelFace(gray, ((x, y, w, h), eyedim)), faceSize))
        # note that for some distributions of python-opencv, the predict function
        # returns the label only.
        #label = recognizer.predict(cv2.resize(detect.levelFace(gray, ((x, y, w, h), eyedim)), faceSize))
        #confidence = -1

        if confidence < threshold:
            found_faces.append((label, confidence,(x,y,w,h)))



    return found_faces

'''
if __name__ == '__main__':
    faceCascade = cv2.CascadeClassifier(config.FACE_CASCADE_FILE)
    eyeCascade = cv2.CascadeClassifier(config.EYE_CASCADE_FILE)
    faceSize = config.DEFAULT_FACE_SIZE
    threshold = 500

    recognizer = train.trainRecognizer('imgdb', faceSize, showFaces=True)

    cv2.namedWindow("camera", 1)
    capture = cv2.VideoCapture(0)

    while True:
        retval, img = capture.read()

        for (label, confidence, (x1, y1, w1, h1)) in RecognizeFace(img, threshold):
        #for (label, confidence, (x1, y1, w1, h1)) in RecognizeFace(img, faceCascade, eyeCascade, faceSize, threshold):
            cv2.rectangle(img, (x1, y1), (x1+w1, y1+h1), (0, 255, 0), 2)
            cv2.putText(img, "{} = {}".format(recognizer.getLabelInfo(label), int(confidence)), (x1, y1), cv2.FONT_HERSHEY_PLAIN, 1, (0,255,0), 1, cv2.LINE_AA)

        cv2.imshow("camera", img)

        if cv2.waitKey(1) & 0xFF == ord('q'):
            break



