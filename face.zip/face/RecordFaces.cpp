// To record faces and write it to a folder
// Created by user on 7/8/17.
//
#include <opencv2/core.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/objdetect.hpp>
#include <opencv2/imgproc.hpp>
#include <iostream>

using namespace cv;
using namespace std;


int main(int argc, char** argv)
{
 // capture from web camera init

 VideoCapture cap(0);
 cap.open(0);

 Mat img;

 // Initialize the inbuilt Harr Cascade frontal face detection
 // Below mention the path of where your haarcascade_frontalface_alt2.xml file is located


    int k =0;


 for (;;)
 {
 
      // Image from camera to Mat

      cap >> img;
    
     // obtain input image from source
     cap.retrieve(img, CV_CAP_OPENNI_BGR_IMAGE);

     // Just resize input image if you want
     resize(img, img, Size(1000,640));



      
      //Show the results
      // Draw circles on the detected faces



     // To draw rectangles around detected faces
   /* for (unsigned i = 0; i<faces.size(); i++) {
       // rectangle(img, faces[i], Scalar(255, 0, 0), 2, 1);
        k++;

        cout << k << endl;

        Rect f = faces[i];

        Mat crop = img(f);
        std::stringstream name;
        //name << "/home/user/ClionProjects/ComputerVision/Name_Templates_Female/" << FONT_HERSHEY_TRIPLEX << "/" << i << "_" << pch << ".jpg";
        */
        std::stringstream name;

        name << "/home/user/Alignment/face/imgdb/Mother/" << k << ".jpg";
        bool maybe = imwrite(name.str(),img);
        //imshow("Cropped Face",crop);

        imshow("wooohooo",img);
        int key2 = waitKey(1);





 }
 return 0;
}
