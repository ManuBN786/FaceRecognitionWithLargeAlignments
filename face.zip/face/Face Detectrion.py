'''
 Face Detection with Alignment Correction using Dlib

'''



import sys

sys.path.append('/usr/local/lib/python3.5/site-packages')
from imutils.face_utils import FaceAligner
from imutils.face_utils import rect_to_bb
import argparse
import imutils
import dlib
import numpy as np
import cv2
import os

# initialize dlib's face detector (HOG-based) and then create
# the facial landmark predictor and the face aligner
detector = dlib.get_frontal_face_detector()
predictor = dlib.shape_predictor("shape_predictor_68_face_landmarks.dat")
fa = FaceAligner(predictor, desiredFaceWidth=256)
#fa = FaceAligner(predictor)
#detector= cv2.CascadeClassifier('/home/user/OpenCV_Installed/opencv-3.2.0/data/haarcascades/haarcascade_frontalface_alt.xml')
cap = cv2.VideoCapture(0)
i = 0

while( True):
    ret, image = cap.read()
    image = imutils.resize(image, width=800)
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # show the original input image and detect faces in the grayscale
    # image
    #cv2.imshow("Input", image)
    rects = detector(gray, 2)

    i = i+1
    # loop over the face detections
    for rect in rects:
        # extract the ROI of the *original* face, then align the face
        # using facial landmarks
        (x, y, w, h) = rect_to_bb(rect)
        #cv2.rectangle(image, (x, y), (x+w, y+h), (0, 255, 0), 2)
        cv2.imshow("Input", image)
        faceOrig = imutils.resize(image[y:y + h, x:x + w], width=256)
        faceAligned = fa.align(image, gray, rect)

        import uuid

        f = str(uuid.uuid4())
        cv2.imwrite("foo/" + f + ".png", faceAligned)

        # display the output images
        cv2.imshow("Original", faceOrig)
        cv2.imshow("Aligned", faceAligned)
        cv2.imwrite("/home/user/Alignment/face/imgdb/Manu BN/" + str(i) + ".jpg", faceAligned)
        # x = cv2.imwrite('Aligned10.png',faceAligned)






    #cv2.imshow('frame', img)
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()

